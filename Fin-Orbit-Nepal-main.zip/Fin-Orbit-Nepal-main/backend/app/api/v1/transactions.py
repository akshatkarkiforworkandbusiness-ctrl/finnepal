from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.user import User
from app.schemas.common import Page, make_page
from app.schemas.transaction import TransactionCreate, TransactionRead, TransactionUpdate
from app.services import transaction_service

router = APIRouter()


@router.post("/transactions", response_model=TransactionRead, status_code=201, summary="Create a transaction", description="Manually records a transaction against one of the calling customer's own businesses.")
async def create_transaction(payload: TransactionCreate, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    txn = await transaction_service.create_transaction(db, user, payload)
    return transaction_service.to_read(txn)


@router.get("/transactions", response_model=Page[TransactionRead], summary="List transactions", description="Paginated list of transactions for a given business owned by the calling customer.")
async def list_transactions(
    business_id: uuid.UUID = Query(..., description="Business to list transactions for."),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    items, total = await transaction_service.list_transactions_for_business(db, user, business_id, page, page_size)
    return make_page([transaction_service.to_read(t) for t in items], total, page, page_size)


@router.get("/transactions/{transaction_id}", response_model=TransactionRead, summary="Get a transaction", description="Fetches a single transaction owned (via its business) by the calling customer.")
async def get_transaction(transaction_id: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    txn = await transaction_service.get_owned_transaction_or_404(db, user, transaction_id)
    return transaction_service.to_read(txn)


@router.patch("/transactions/{transaction_id}", response_model=TransactionRead, summary="Update a transaction", description="Partially updates a transaction owned by the calling customer.")
async def patch_transaction(transaction_id: uuid.UUID, payload: TransactionUpdate, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    txn = await transaction_service.get_owned_transaction_or_404(db, user, transaction_id)
    txn = await transaction_service.update_transaction(db, txn, payload)
    return transaction_service.to_read(txn)


@router.delete("/transactions/{transaction_id}", status_code=204, summary="Delete a transaction", description="Deletes a transaction owned by the calling customer.")
async def delete_transaction(transaction_id: uuid.UUID, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    txn = await transaction_service.get_owned_transaction_or_404(db, user, transaction_id)
    await transaction_service.delete_transaction(db, txn)
